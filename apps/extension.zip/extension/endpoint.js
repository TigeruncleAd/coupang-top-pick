export const DEV_ENDPOINT = 'http://localhost:3000'
export const ENDPOINT = 'https://coupang-top-pick-web.vercel.app'
